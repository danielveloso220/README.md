package clinicaapp;

public class ClinicaApp {
    public static void main(String[] args) {
        new TelaLogin().setVisible(true);
    }
}
